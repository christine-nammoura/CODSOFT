let displayValue = '';
let currentOperation = null;
let firstOperand = null;

function appendNumber(number) {
    displayValue += number;
    updateDisplay();
}

function chooseOperation(operation) {
    if (displayValue === '') return;
    if (firstOperand !== null) {
        calculateResult();
    }
    currentOperation = operation;
    firstOperand = displayValue;
    displayValue = '';
}

function calculateResult() {
    if (currentOperation === null || displayValue === '') return;
    let result;
    const secondOperand = displayValue;
    switch (currentOperation) {
        case '+':
            result = parseFloat(firstOperand) + parseFloat(secondOperand);
            break;
        case '-':
            result = parseFloat(firstOperand) - parseFloat(secondOperand);
            break;
        case '*':
            result = parseFloat(firstOperand) * parseFloat(secondOperand);
            break;
        case '/':
            result = parseFloat(firstOperand) / parseFloat(secondOperand);
            break;
        default:
            return;
    }
    displayValue = result.toString();
    currentOperation = null;
    firstOperand = null;
    updateDisplay();
}

function clearDisplay() {
    displayValue = '';
    currentOperation = null;
    firstOperand = null;
    updateDisplay();
}

function updateDisplay() {
    document.getElementById('display').innerText = displayValue || '0';
}
